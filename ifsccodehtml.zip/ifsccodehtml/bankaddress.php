<?php
$host = "localhost";
$username = "root";
$password = '';
$database = "db user"; // Corrected database name

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die('Could not connect: ' . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $Bankname = $_POST["bankname"];
    $product = $_POST["Branch"];
    $IFScode = $_POST["IFSCCode"];
    $Address = $_POST['Location'];
    $dis = $_POST['District'];
    $state = $_POST['State'];

    $sql = "INSERT INTO bank3 (bankname, Branch, IFSCCode, Location, District, State) VALUES ('$Bankname', '$product', '$IFScode', '$Address', '$dis', '$state')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Submitted successfully');</script>";
        echo "<script>window.location.href='bank address.html';</script>";
        // Add any further actions after successful registration
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

echo 'Connected successfully';
$conn->close();
?>
