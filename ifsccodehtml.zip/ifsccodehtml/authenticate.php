<?php
$host = "localhost";   
$username = "root";      
$password = "";      
$database = "db user"; 
$conn = new mysqli($host, $username, $password, $database);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER ["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

   
    $sql = "SELECT * FROM usersignup WHERE username = '$username' AND password = '$password'";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "Login successfull !";

        header(header:"location:front.html");
        
    } else {
        echo "Invalid username or password";
    }
}
$conn->close();
?>