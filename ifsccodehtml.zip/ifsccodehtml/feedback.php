<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "db user"; // Replace with your actual database name

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die('Could not connect: ' . $conn->connect_error);
}

$sql = "SELECT * FROM contactus";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table border='1'>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Message</th>
        </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['name']}</td>
                <td>{$row['email']}</td>
                <td>{$row['phone']}</td>
                <td>{$row['msg']}</td>
            </tr>";
    }

    echo "</table>";
} else {
    echo "No records found";
}

mysqli_close($conn);
?>
