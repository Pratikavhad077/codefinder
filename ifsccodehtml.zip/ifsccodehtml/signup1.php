<?php
$host = "localhost";
$username = "root";
$password = '';
$database = "db user";
$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die('Could not connect: ' . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //$id=$_POST["id"];
    $username = $_POST["username"];
    $Email= $_POST["email"];
    $upass=$_POST["Password"];
    $conpass=$_POST['ConPassword'];
   

    $sql = "INSERT INTO usersignup(username, email,Password,ConPassword) VALUES ('$username', '$Email','$upass','$conpass')";
    $result = $conn->query($sql);

    if ($result === TRUE) {
        echo "Registration successfully";
            // Registration successful, redirect to login page
            header("Location: login.html");
        // Add any further actions after successful registration
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

echo 'Connected successfully';
mysqli_close($conn);
?>
