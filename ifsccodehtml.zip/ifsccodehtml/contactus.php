<?php
$host = "localhost";
$username = "root";
$password = '';
$database = "db user";
$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die('Could not connect: ' . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //$id=$_POST["id"];
    $username = $_POST["name"];
    $Email= $_POST["email"];
    $Phone=$_POST["phone"];
    $Message=$_POST['msg'];
   
    $sql = "INSERT INTO contactus(name, email,phone,msg) VALUES ('$username', '$Email','$Phone','$Message')";
    $result = $conn->query($sql);

    if ($result === TRUE) {
        echo '<script>alert("Connected to Database successfully");</script>';
        echo '<script>
                setTimeout(function(){
                    window.location.href = "home.html";
                }, 1300); // Adjust the delay time in milliseconds (e.g., 2000 for 2 seconds)
              </script>';
        // Add any further actions after successful registration
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

echo 'Submitted Successfully';
mysqli_close($conn);
?>
