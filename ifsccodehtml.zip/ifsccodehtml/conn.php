<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "db user";
$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['aname'];
    $password = $_POST['apass'];

    // Use prepared statements to prevent SQL injection
    $sql = "SELECT * FROM adminlogin WHERE aname = ? AND apass = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "Login successful!";
        
        // Redirect to adminpanel.html
        header("Location: adminpanel.html");
        exit(); // Ensure that script stops after redirection
    } else {
        echo "Invalid username or password";
    }
}

$conn->close();
?>
